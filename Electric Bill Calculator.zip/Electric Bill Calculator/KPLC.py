def calculate_bill():
    # Prompt the user for customer details
    customer_id = input("Enter Customer ID: ")
    customer_name = input("Enter Customer Name: ")
    units_consumed = int(input("Enter Units Consumed: "))

    # Initialize variables
    charges_per_unit = 0
    total_amount = 0

    # Calculate charges per unit based on units consumed
    if units_consumed < 200:
        charges_per_unit = 1.20
    elif units_consumed >= 200 and units_consumed < 400:
        charges_per_unit = 1.50
    elif units_consumed >= 400 and units_consumed < 600:
        charges_per_unit = 1.80
    else:
        charges_per_unit = 2.00

    # Calculate total bill
    total_amount = units_consumed * charges_per_unit

    # Apply surcharge if bill exceeds Kshs. 400
    if total_amount > 400:
        surcharge = total_amount * 0.15
        total_amount += surcharge

    # Apply minimum bill of Kshs. 100
    if total_amount < 100:
        total_amount = 100

    # Display the output
    print("Customer ID:", customer_id)
    print("Customer Name:", customer_name)
    print("Units Consumed:", units_consumed)
    print("Charges per Unit (Ksh):", charges_per_unit)
    print("Total Amount to Pay (Ksh):", total_amount)


# Call the function to calculate the bill
calculate_bill()